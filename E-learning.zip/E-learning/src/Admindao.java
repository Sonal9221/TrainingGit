import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Admindao {
	private String dburl="jdbc:oracle:thin://localhost:1521/orcl/Project";
	private String dbname="sys as sysdba";
	private String dbpassword="system";
	private String dbdriver="oracle.jdbc.driver.OracleDriver";
	

	
	public void loadDriver(String dbDriver)

	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbname,dbpassword);
			}
		catch(SQLException e)
		{
			e.printStackTrace();
		
		}
		return con;
	}
	public String insert1(Admin admin)
	{

		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="Admin Login Successfully";
		String sql="insert into Admin values(?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, admin.getAdmin_id());
			ps.setString(2, admin.getName());
			
			ps.setString(3, admin.getEmail());
		
			ps.setString(4, admin.getPassword());
			ps.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="Data not entered";
		}
		
		return result;
	}

}