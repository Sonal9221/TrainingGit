import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Enrolldao {
	private String dburl="jdbc:oracle:thin://localhost:1521/orcl/Project";
	private String dbname="sys as sysdba";
	private String dbpassword="system";
	private String dbdriver="oracle.jdbc.driver.OracleDriver";
	
	
	public void loadDriver(String dbDriver)

	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbname,dbpassword);
			}
		catch(SQLException e)
		{
			e.printStackTrace();
		
		}
		return con;
	}
	public String insert(Coursedetails coursedetails)

	{
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="You have enrolled in course successfully";
		String sql="insert into course values(?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, coursedetails.getCourse_id());
			ps.setString(2,coursedetails.getC_name());
			ps.setString(3,coursedetails.getC_desp());
			ps.setString(4, coursedetails.getC_fees());
			ps.setString(5,coursedetails .getC_resource());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="Data not entered";
		}
		return result;
		

}
}
