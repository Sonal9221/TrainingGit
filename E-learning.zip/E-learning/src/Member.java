
public class Member {
	private Integer id;
	private Integer phone_no;
	private String name;
	private String address;
	private String email;
	private String reg_date;
	private String password;
	private String upload_photo;
	public Member(Integer id, Integer phone_no, String name, String address, String email, String reg_date,
			String password, String upload_photo) {
		super();
		this.id = id;
		this.phone_no = phone_no;
		this.name = name;
		this.address = address;
		this.email = email;
		this.reg_date = reg_date;
		this.password = password;
		this.upload_photo = upload_photo;
	}
	public Member() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(Integer phone_no) {
		this.phone_no = phone_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUpload_photo() {
		return upload_photo;
	}
	public void setUpload_photo(String upload_photo) {
		this.upload_photo = upload_photo;
	}

		


}

	