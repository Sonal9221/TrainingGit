

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	 String id=request.getParameter("id");
	
	String name=request.getParameter("name");
	String address=request.getParameter("address");
	String phone_no=request.getParameter("phone_no");
	String email=request.getParameter("email");
	String password=request.getParameter("password");
	String reg_date=request.getParameter("reg_date");
	
	
	
	Member member=new Member(Integer.valueOf(id), Integer.valueOf(phone_no), name, address, email,  reg_date,
				password,"img.jpg");
	 
	 
	
	UserRegisterdao rdao=new UserRegisterdao();
	String result=rdao.insert(member);
	//response.getWriter().print(result);
	request.setAttribute("message", result);
    request.getRequestDispatcher("/Menulist.jsp").forward(request, response);
	
	}
}
