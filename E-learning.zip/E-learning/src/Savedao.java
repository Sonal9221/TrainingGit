import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Savedao {
	private String dburl="jdbc:oracle:thin://localhost:1521/orcl/Project";
	private String dbname="sys as sysdba";
	private String dbpassword="system";
	private String dbdriver="oracle.jdbc.driver.OracleDriver";
	
	
	public void loadDriver(String dbDriver)

	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbname,dbpassword);
			}
		catch(SQLException e)
		{
			e.printStackTrace();
		
		}
		return con;
	}
	public String insert(Contactdetails contactdetails)

	{
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="Contact details saved successfully";
		String sql="insert into contact values(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, contactdetails.getId());
			ps.setString(2,contactdetails.getName());
			ps.setString(3,contactdetails.getEmail());
			ps.setInt(4, contactdetails.getPhone_no());
			
			ps.setString(5,contactdetails .getMessage());
			ps.setInt(6,contactdetails .getContact_id());
			
			
		
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="Data not entered";
		}
		return result;
		

}
}
