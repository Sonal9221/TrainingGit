import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Submitdao {
	
	
	
	private String dburl="jdbc:oracle:thin://localhost:1521/orcl/Project";
	private String dbname="sys as sysdba";
	private String dbpassword="system";
	private String dbdriver="oracle.jdbc.driver.OracleDriver";
	
	
	public void loadDriver(String dbDriver)

	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbname,dbpassword);
			}
		catch(SQLException e)
		{
			e.printStackTrace();
		
		}
		return con;
	}
	public String insert(Feedbackdetails feedbackdetails)

	{
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="Your feedback has been saved successfully ";
		String sql="insert into feedback values(?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, feedbackdetails.getId());
			ps.setString(2,feedbackdetails .getName());
			ps.setString(3, feedbackdetails.getEmail());
			ps.setInt(4,feedbackdetails .getF_id());
		ps.setString(5,feedbackdetails.getInsight());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="Data not entered";
		}
		return result;
		
	}
}


