import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserRegisterdao {
	private String dburl="jdbc:oracle:thin://localhost:1521/orcl/Project";
	private String dbname="sys as sysdba";
	private String dbpassword="system";
	private String dbdriver="oracle.jdbc.driver.OracleDriver";
	
	
	public void loadDriver(String dbDriver)

	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbname,dbpassword);
			}
		catch(SQLException e)
		{
			e.printStackTrace();
		
		}
		return con;
	}
	public String insert(Member member)

	{
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="Registration Successful";
		String sql="insert into UserName values(?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, member.getName());
			ps.setInt(2,member .getId());
			ps.setString(3,member.getAddress());
			ps.setInt(4, member.getPhone_no());
			ps.setString(5, member.getEmail());
			ps.setString(6,member .getReg_date());
			ps.setString(7, member .getPassword());
			
			ps.setString(8,"img.jpg");
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="Data not entered";
		}
		return result;
		
	}
	
	
}
